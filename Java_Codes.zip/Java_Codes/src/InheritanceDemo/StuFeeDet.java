package InheritanceDemo;

public class StuFeeDet extends StuMarksDet{
int feedet;
public void a()
{
	System.out.println("Enter Fees");
	feedet=sc.nextInt();
	super.acc();
	super.accept();
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
