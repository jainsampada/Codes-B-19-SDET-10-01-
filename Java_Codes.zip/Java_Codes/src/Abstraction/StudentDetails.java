package Abstraction;

import java.util.Scanner;

interface StudentDetails  {
	 int a=10;
	 Scanner s=new Scanner(System.in);
void perdet();
void coursedet();
void feedet();
}
