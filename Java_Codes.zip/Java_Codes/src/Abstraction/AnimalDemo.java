package Abstraction;

abstract class AnimalDemo {
int a;
abstract void eat();//Abstract Method
void drink()//Non Abstarct/Concrete Method
{
	System.out.println("All animals drink water");
}
}
