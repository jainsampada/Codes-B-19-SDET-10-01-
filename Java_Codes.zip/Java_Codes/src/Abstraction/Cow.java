package Abstraction;

public class Cow extends AnimalDemo{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	void eat() {
		// TODO Auto-generated method stub
		System.out.println("Cow eats Veg");
	}

}
