package StringDemo;

public class FirstDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name="ShaliniRj";
		String name1="Pooja";
		name=name.concat(name1);
		int num=10;
		num+=2;
		System.out.println(num);
		System.out.println(name);
		System.out.println(name.charAt(4));

	}

}
