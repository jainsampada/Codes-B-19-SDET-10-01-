package StringDemo;

public class ConcatDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10,b=22;
char s='a';
String s1="is whole no";
System.out.println(a+b+s1+s);
	}

}
 