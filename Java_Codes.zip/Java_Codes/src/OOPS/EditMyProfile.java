package OOPS;

public class EditMyProfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentDemo oo=new StudentDemo();
		
		System.out.println(oo.getRoll());
	}

}
