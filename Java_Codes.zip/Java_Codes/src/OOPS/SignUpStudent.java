package OOPS;

public class SignUpStudent {
public void insert()
{
StudentDemo oo=new StudentDemo();
//oo.getRollno();
System.out.println(oo.getRollno());
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			SignUpStudent oo=new SignUpStudent();
			oo.insert();
	}

}
