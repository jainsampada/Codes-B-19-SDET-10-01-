package OOPS;

public class Demo {
static int num;
float a;
String name;
double b;
byte c;
long val;
char vowel;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(num);
//		Demo oo=new Demo();
//		System.out.println(oo.num);
//		oo.num++;
//		System.out.println(oo.num);
//	Demo obj=new Demo();
//	System.out.println(obj.num);
//		System.out.println(oo.a);
//		System.out.println(oo.name);
//		System.out.println(oo.b);
//		System.out.println(oo.c);
//		System.out.println(oo.val);
//		System.out.println(oo.vowel);
//		System.out.println(oo.val);
	}

}
